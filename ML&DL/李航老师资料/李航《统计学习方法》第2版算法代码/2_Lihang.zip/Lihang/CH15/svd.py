#! /usr/bin/env python
#! -*- coding=utf-8 -*-
# Project:  Lihang
# Filename: svd
# Date: 5/23/19
# Author: 😏 <smirk dot cao at gmail dot com>
import numpy as np

