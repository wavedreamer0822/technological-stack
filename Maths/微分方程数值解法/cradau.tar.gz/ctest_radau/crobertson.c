/* Sample implementation for using radau/radau5 with C.
   This program solves the Robertson equation 
   (cf. E.Hairer/G.Wanner: Solving ordinary differential
   equations, IV.1, pp. 3-4)
   The radau/radau5 codes are called directly and via
   the simplified C-interface.
   (c) Michael Hauth, 2001.
  */

#include "../radau/radau.h"
#include <stdio.h>


/* this is the right-hand side function */
void rob(int *n, double *x, double *y, double *fy, 
		   double *rpar, int *ipar)
{
	fy[0]=-0.04 *y[0]+1.e4*y[1]*y[2];
	fy[2]=3.e7*y[1]*y[1];
	fy[1]=-fy[0]-fy[2];

}

/* writes the jacobian in transposed form */
void jrob(int *n, double *x, double *y, double *dfy,
		   int *ldfy, double *rpar, double *ipar)
{
	/* make comfortable 2D acces */
	/* dfy is a (ldfy,n) matrix in colum major storage*/
	double *J[3];
	int i;
	double prod1,prod2,prod3;
	/* set J to first elt. of each column */
	for (i=0;i<*n;++i)
	  J[i]=&dfy[i* *ldfy];

	prod1=1.0e4*y[1];
	prod2=1.0e4*y[2];
	prod3=6.0e7*y[1];
	J[0][0]=-0.04;
	J[1][0]=prod2;
	J[2][0]=prod1;
	J[0][1]=0.04;
	J[1][1]=-prod2-prod3;
	J[2][1]=-prod1;
	J[0][2]=0.0;
	J[1][2]=prod3;
	J[2][2]=0.0;
	
	
}

/* dummy function, the equation is explicit */
void mass_dummy(int *n,double *am, int *lmas,int *rpar, int *ipar)
{
}

/* solout function. Because the continuous output is not
   used, the same function can be used for radau and radau5 */
void solout(int *nr,double *xold,double *x,
			double *y,
			double *cont,int *lrc,
			int *n,
			double *rpar,int *ipar,
			int *irtrn)
{
	printf("Step %3i: t=%1.3e, y=(%1.3e,%1.3e)\n",*nr, *x,y[0],y[1]);
}





int main()
{
 
	/* for the definition of the (static) workspace */
#define ND     3
#define NS     7
#define LWORK  (NS+1)*ND*ND+(3*NS+3)*ND+20
#define LIWORK (2+(NS-1)/2)*ND+20

	double y[ND],work[LWORK];
	int iwork[LIWORK];
	double x,xend;
	int i,idid;
	
	/*(no) parameter in the differential equation*/
	double   rpar=0;
	/*dimension of the system*/
	int  n=3;
	/* compute the jacobian analytically */
	int ijac=1;
	/* jacobian is a full matrix*/
	int mljac=n;
	int mujac=0;
	/* differential equation is in explicit form*/
	int imas=0;
	int mlmas=0;
	int mumas;
	int ipar=0;
	/* output routine is used during integration*/
	int iout=1;
	
	/* required tolerance*/
	double rtol=1.0e-2;
	double atol=1.0e-6*rtol;
	int itol=0;
	/* initial step size*/
	double h=1.0e-6;
	
	int lwork=LWORK;
	int liwork=LIWORK;
	
	/* initial values*/
	x=0.0;
	y[0]=1.0;
	y[1]=0.0;
	y[2]=0.0;
	
	/* endpoint of integration*/
	xend=1.0;
	/* set default values */
	for(i=0; i<20; i++){
		iwork[i]=0;
		work[i]=0.0;
	}


	printf("\n**********\n* radau  *\n**********\n\n");

	RADAU(&n,rob,&x,y,&xend,&h,
		&rtol,&atol,&itol,
		jrob,&ijac,&mljac,&mujac,
		mass_dummy,&imas,&mlmas,&mumas,
		solout,&iout,
		work,&lwork,iwork,&liwork,&rpar,&ipar,&idid);
	
	/* print final solution */
	printf("y(%1.4f) = ( %1.4e, %1.4e)\n",  x,y[0],y[1]);
	
	/* print statistics */
	printf("rtol = %1.2e\n",rtol);
	printf("fcn= %i jac= %i step= %i accpt= %i rejct= %i dec= %i sol= %i\n",
		iwork[13],iwork[14],iwork[15],iwork[16],iwork[17],iwork[18],iwork[19]);

	x=0.0;
	y[0]=1.0;
	y[1]=0.0;
	y[2]=0.0;
	for(i=0; i<20; i++){
		iwork[i]=0;
		work[i]=0.0;
	}
	
	cradau(n,rob,0.0,y,1.0,1e-6,
		rtol,atol,
		jrob,ijac,mljac,mujac,
		mass_dummy,imas,mlmas,mumas,
		solout,iout,
		work,iwork,&rpar,&ipar,&idid);

	/* print final solution */
	printf("y(%1.4f) = ( %1.4e, %1.4e)\n",  x,y[0],y[1]);
	
	/* print statistics */
	printf("rtol = %1.2e\n",rtol);
	printf("fcn= %i jac= %i step= %i accpt= %i rejct= %i dec= %i sol= %i\n",
		iwork[13],iwork[14],iwork[15],iwork[16],iwork[17],iwork[18],iwork[19]);

	x=0.0;
	h=1.0e-6;
	y[0]=1.0;
	y[1]=0.0;
	y[2]=0.0;
	for(i=0; i<20; i++){
		iwork[i]=0;
		work[i]=0.0;
	}
	

	printf("\n**********\n* radau5 *\n**********\n\n");
	RADAU5(&n,rob,&x,y,&xend,&h,
		&rtol,&atol,&itol,
		jrob,&ijac,&mljac,&mujac,
		mass_dummy,&imas,&mlmas,&mumas,
		solout,&iout,
		work,&lwork,iwork,&liwork,&rpar,&ipar,&idid);
	
	/* print final solution */
	printf("y(%1.4f) = ( %1.4e, %1.4e)\n",  x,y[0],y[1]);
	
	/* print statistics */
	printf("rtol = %1.2e\n",rtol);
	printf("fcn= %i jac= %i step= %i accpt= %i rejct= %i dec= %i sol= %i\n",
		iwork[13],iwork[14],iwork[15],iwork[16],iwork[17],iwork[18],iwork[19]);

	x=0.0;
	y[0]=1.0;
	y[1]=0.0;
	y[2]=0.0;
	for(i=0; i<20; i++){
		iwork[i]=0;
		work[i]=0.0;
	}
	for(i=0; i<20; i++){
		iwork[i]=0;
		work[i]=0.0;
	}

	cradau5(n,rob,0.0,y,1.0,1e-6,
		rtol,atol,
		jrob,ijac,mljac,mujac,
		mass_dummy,imas,mlmas,mumas,
		solout,iout,
		work,iwork,&rpar,&ipar,&idid);

	printf("y(%1.4f) = ( %1.4e, %1.4e)\n",  x,y[0],y[1]);
	
	/* print statistics */
	printf("rtol = %1.2e\n",rtol);
	printf("fcn= %i jac= %i step= %i accpt= %i rejct= %i dec= %i sol= %i\n",
		iwork[13],iwork[14],iwork[15],iwork[16],iwork[17],iwork[18],iwork[19]);

	
	return 0;
}
