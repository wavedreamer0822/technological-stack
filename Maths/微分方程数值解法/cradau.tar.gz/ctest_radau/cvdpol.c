/* Sample implementation for using radau/radau5 with C.
   This program solves van der Pol's equation 
   (cf. E.Hairer/G.Wanner: Solving ordinary differential
   equations, IV.1, pp. 4-6)
   The radau/radau5 codes are called directly and via
   the simplified C-interface.
   (c) Michael Hauth, 2001.
  */

#include "../radau/radau.h"
#include <stdio.h>

/* right-hand-side function */
void vdpol(int *n, double *x, double *y, double *fy, 
		   double *rpar, int *ipar)
{
	fy[0]=y[1];
	fy[1]=( (1-y[0]*y[0]) * y[1]-y[0])/rpar[0];

}

/* writes the jacobian in transposed (i.e. column major) form */
void jvpol(int *n, double *x, double *y, double *dfy,
		   int *ldfy, double *rpar, double *ipar)
{
	/* make comfortable 2D acces */
	/* dfy is a (ldfy,n) matrix in colum major storage*/
	double *J[2];
	int i;
	/* set J to first elt. of each column */
	for (i=0;i<*n;++i)
	  J[i]=&dfy[i* *ldfy];


	J[0][0]=0.0;
	J[1][0]=1.0;
	J[0][1]=(-2.0*y[0]*y[1]-1.0)/rpar[0];
	J[1][1]=(1.0-y[0]*y[0])/rpar[0];
}

/* dummy function, the equation is explicit */
void mass_dummy(int *n,double *am, int *lmas,int *rpar, int *ipar)
{
}

/* this function is called after each integration step.
   either output is written after each step, or
   after specified time intervals using the continous output
   function contra */
void solout(int *nr,double *xold,double *x,
			double *y,
			double *cont,int *lrc,
			int *n,
			double *rpar,int *ipar,
			int *irtrn)
{

	/*#define EVERY_STEP*/

#ifdef EVERY_STEP
	printf("Step %3i: t=%1.3e, y=(%1.3e,%1.3e)\n",*nr, *x,y[0],y[1]);
#else
	static double d;
	double yd[2];
	if (*nr==1) d=*xold;
	if ((*xold<=d) && (*x>=d)){
		yd[0]=ccontra(1, d, cont, lrc);
		yd[1]=ccontra(2, d, cont, lrc);
		printf("Step %3i: t=%1.3e, y=(%1.3e,%1.3e)\n",*nr, d, yd[0],yd[1]);
		d+=0.2;
	}
#endif

}

/* this is the slout function for radau5.
   As we use the continuous output function, we need
   a special version calling contr5 */
void solout5(int *nr,double *xold,double *x,
			double *y,
			double *cont,int *lrc,
			int *n,
			double *rpar,int *ipar,
			int *irtrn)
{

#ifdef EVERY_STEP
	printf("Step %3i: t=%1.3e, y=(%1.3e,%1.3e)\n",*nr, *x,y[0],y[1]);
#else
	static double d;
	double yd[2];
	if (*nr==1) d=*xold;
	if ((*xold<=d) && (*x>=d)){
		yd[0]=ccontr5(1, d, cont, lrc);
		yd[1]=ccontr5(2, d, cont, lrc);
		printf("Step %3i: t=%1.3e, y=(%1.3e,%1.3e)\n",*nr, d, yd[0],yd[1]);
		d+=0.2;
	}
#endif

}


int main()
{

#define ND     2
#define NS     7
#define LWORK  (NS+1)*ND*ND+(3*NS+3)*ND+20
#define LIWORK (2+(NS-1)/2)*ND+20

	double y[ND],work[LWORK];
	int iwork[LIWORK];
	double x,xend;
	int i,idid;
	
	/*parameter in the differential equation*/
	double   rpar=1e-6;
	/*dimension of the system*/
	int  n=2;
	/* compute the jacobian analytically */
	int ijac=1;
	/* jacobian is a full matrix*/
	int mljac=n;
	int mujac=0;
	/* differential equation is in explicit form*/
	int imas=0;
	int mlmas=0;
	int mumas;
	int ipar=0;
	/* output routine is used during integration*/
	int iout=1;
	
	/* required tolerance*/
	double rtol=1.0e-7;
	double atol=1.0*rtol;
	int itol=0;
	/* initial step size*/
	double h=1.0e-6;
	
	int lwork=LWORK;
	int liwork=LIWORK;
	
	/* initial values*/
	x=0.0;
	y[0]=2.0;
	y[1]=-0.66;
	
	/* endpoint of integration*/
	xend=2.0;
	/* set default values */
	for(i=0; i<20; i++){
		iwork[i]=0;
		work[i]=0.0;
	}

	printf("\n**********\n* radau  *\n**********\n\n");
	/* directly calling fortran */
	RADAU(&n,vdpol,&x,y,&xend,&h,
		&rtol,&atol,&itol,
		jvpol,&ijac,&mljac,&mujac,
		mass_dummy,&imas,&mlmas,&mumas,
		solout,&iout,
		work,&lwork,iwork,&liwork,&rpar,&ipar,&idid);
	
	/* print final solution */
	printf("y(%1.4f) = ( %1.4e, %1.4e)\n",  x,y[0],y[1]);
	
	/* print statistics */
	printf("rtol = %1.2e\n",rtol);
	printf("fcn= %i jac= %i step= %i accpt= %i rejct= %i dec= %i sol= %i\n",
		iwork[13],iwork[14],iwork[15],iwork[16],iwork[17],iwork[18],iwork[19]);

	/* new call of radau using the c-wrapper */
	/* reset values */
	x=0.0;
	y[0]=2.0;
	y[1]=-0.66;
	for(i=0; i<20; i++){
		iwork[i]=0;
		work[i]=0.0;
	}

	
	/* note that some values can here be passed directly */
	cradau(n,vdpol,0.0,y,2.0,1e-6,
		rtol,atol,
		jvpol,ijac,mljac,mujac,
		mass_dummy,imas,mlmas,mumas,
		solout,iout,
		work,iwork,&rpar,&ipar,&idid);
		/* print final solution */
	printf("y(%1.4f) = ( %1.4e, %1.4e)\n",  x,y[0],y[1]);
	
	/* print statistics */
	printf("rtol = %1.2e\n",rtol);
	printf("fcn= %i jac= %i step= %i accpt= %i rejct= %i dec= %i sol= %i\n",
		iwork[13],iwork[14],iwork[15],iwork[16],iwork[17],iwork[18],iwork[19]);

	/* radau5 */
	printf("\n**********\n* radau5 *\n**********\n\n");

	/* reset values */
	x=0.0;
	h=1.0e-6;
	y[0]=2.0;
	y[1]=-0.66;
	
	/* directly calling fortran */
	RADAU5(&n,vdpol,&x,y,&xend,&h,
		&rtol,&atol,&itol,
		jvpol,&ijac,&mljac,&mujac,
		mass_dummy,&imas,&mlmas,&mumas,
		solout5,&iout,
		work,&lwork,iwork,&liwork,&rpar,&ipar,&idid);
	
	/* print final solution */
	printf("y(%1.4f) = ( %1.4e, %1.4e)\n",  x,y[0],y[1]);
	
	/* print statistics */
	printf("rtol = %1.2e\n",rtol);
	printf("fcn= %i jac= %i step= %i accpt= %i rejct= %i dec= %i sol= %i\n",
		iwork[13],iwork[14],iwork[15],iwork[16],iwork[17],iwork[18],iwork[19]);

	/* new call of radau using the c-wrapper */
	x=0.0;
	y[0]=2.0;
	y[1]=-0.66;
	
	cradau5(n,vdpol,0.0,y,2.0,1e-6,
		rtol,atol,
		jvpol,ijac,mljac,mujac,
		mass_dummy,imas,mlmas,mumas,
		solout5,iout,
		work,iwork,&rpar,&ipar,&idid);
	/* print final solution */
	printf("y(%1.4f) = ( %1.4e, %1.4e)\n",  x,y[0],y[1]);
	
	/* print statistics */
	printf("rtol = %1.2e\n",rtol);
	printf("fcn= %i jac= %i step= %i accpt= %i rejct= %i dec= %i sol= %i\n",
		iwork[13],iwork[14],iwork[15],iwork[16],iwork[17],iwork[18],iwork[19]);


	return 0;
}



