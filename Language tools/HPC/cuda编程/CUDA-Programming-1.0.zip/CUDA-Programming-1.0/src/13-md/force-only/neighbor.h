#pragma once
#include "common.h"

void find_neighbor(int N, int MN, Atom *atom);
