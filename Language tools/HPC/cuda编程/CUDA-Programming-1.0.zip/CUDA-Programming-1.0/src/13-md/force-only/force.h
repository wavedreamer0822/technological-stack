#pragma once
#include "common.h"

void find_force(int N, int MN, Atom *atom);

