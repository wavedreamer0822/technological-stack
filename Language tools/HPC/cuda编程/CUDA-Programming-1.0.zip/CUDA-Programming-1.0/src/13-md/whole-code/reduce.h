#include "common.h"

real sum(const int N, const real *d_x);

